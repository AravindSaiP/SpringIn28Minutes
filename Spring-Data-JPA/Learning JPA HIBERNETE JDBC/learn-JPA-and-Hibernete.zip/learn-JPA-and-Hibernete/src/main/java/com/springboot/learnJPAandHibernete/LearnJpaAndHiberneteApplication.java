package com.springboot.learnJPAandHibernete;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearnJpaAndHiberneteApplication {

	public static void main(String[] args) {
		SpringApplication.run(LearnJpaAndHiberneteApplication.class, args);
	}

}
