package com.learn_spring_boot.basic_restapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BasicRestapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(BasicRestapiApplication.class, args);
	}

}
