package com.example.jstltest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JstltestApplicationTests {

	@Test
	void contextLoads() {
	}

}
