package com.example.jstltest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JstltestApplication {

	public static void main(String[] args) {
		SpringApplication.run(JstltestApplication.class, args);
	}

}
