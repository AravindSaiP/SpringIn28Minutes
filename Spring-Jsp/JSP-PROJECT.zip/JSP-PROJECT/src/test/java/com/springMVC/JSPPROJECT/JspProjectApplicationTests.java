package com.springMVC.JSPPROJECT;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JspProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
