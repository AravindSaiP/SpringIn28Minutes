package com.spring_framework.learnspringframework02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearnSpringFramework02ApplicationTests {

	@Test
	void contextLoads() {
	}

}
